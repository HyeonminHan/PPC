#pragma once

#define BOOST_TYPEOF_EMULATION

#define MSR3DVideo_Ballet 0
#define Poznan_Fencing 1
#define Intel_Kermit 2
#define Technicolor_Painter 3
#define hotelroom_r2_front_sample 4

#include "stdio.h"
#include "stdlib.h"
#include <windows.h>
#include <iostream>
#include "opencv.hpp"
#include <pcl/io/io.h>
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include <pcl/io/eigen.h>
#include <pcl/visualization/cloud_viewer.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/io/pcd_io.h>
#include <pcl/console/parse.h>
#include <pcl/common/transforms.h>
#include <pcl/ModelCoefficients.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include <math.h>
#include <pcl/io/ply_io.h>
#include <pcl/io/ascii_io.h>
#include <pcl/io/vtk_lib_io.h>
#include <pcl/PCLPointCloud2.h>
#include <pcl/point_traits.h>
#include <pcl/common/io.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/io/pcd_io.h>
#include <list>
#include <pcl/registration/icp.h>
#include <ctime>
#include <pcl/features/normal_3d.h>
#include <fstream>
#include <vector>
#include <algorithm>
#include <iomanip>

using namespace pcl;
using namespace std;
using namespace io;
using namespace cv;
using namespace Eigen;
using namespace visualization;

typedef struct {
	Matrix3d m_K;
	Matrix3d m_RotMatrix;
	Matrix3Xd m_Trans;
	Matrix4d m_ProjMatrix;
} CalibStruct;

extern int mode, _width, _height, total_num_cameras, total_num_frames, color_bits, depth_bits;;
extern double MinZ, MaxZ;
extern vector<Vector2d> tech_minmaxZ;
extern string path;
extern vector<CalibStruct> m_CalibParams;
extern vector<float> geo_min, geo_max;

//typedef struct {
//	//int num_of_cam;
//	float geometry[3];
//	short color[10][3];//[num_of_cam][color_index]
//	bool occlusion_pattern[10];
//	//vector<vector<float>> color;
//} PPC;

// VUY ������.
typedef struct PPC_ 
{
	float geometry[3];
	uchar refV;
	uchar refU;
	vector<uchar> VU;
	vector<uchar> Y;

	PPC_() 
	{
		// occlusion���� �ʱ�ȭ.
		VU = vector<uchar>(total_num_cameras, uchar(255));
		Y = vector<uchar>(total_num_cameras);
	}

	bool CheckOcclusion(int idx) 
	{
		return int(VU[idx]) == 255;
	}

	Vec3b GetColor(int idx)
	{
		Vec3b vuy;
		int firstCamNum = 0;
		for (int i = 0; i < total_num_cameras; i++) {
			if (!CheckOcclusion(i)) {
				firstCamNum = i;
				break;
			}
		}

		uchar v = refV;
		uchar u = refU;
		for (int i = firstCamNum + 1; i <= idx; i++) {
			if (!CheckOcclusion(i)) {
				v += (VU[i] >> 4) - 7;
				u += (uchar(VU[i] << 4) >> 4) - 7;
			}
		}
		vuy[0] = v;
		vuy[1] = u;

		vuy[2] = Y[idx];

		return vuy;
	}

	void SetOcclusion(int idx) {
		VU[idx] = uchar(255);
	}
	
	// color��  YUV
	void SetRefColor(Vec3b color, int idx)
	{
		//for (int i = 0; i < idx; i++) {
		//	SetOcclusion(i);
		//}

		refV = color[2];
		refU = color[1];
		Y[idx] = color[0];

		VU[idx] = 0;
	}

	// color�� VUY
	void SetRefColor(PointXYZRGB point, int idx)
	{
		//for (int i = 0; i < idx; i++) {
		//	SetOcclusion(i);
		//}

		refV = point.r;
		refU = point.g;
		Y[idx] = point.b;

		VU[idx] = 0;
	}

	// color�� yuv
	void SetColor(Vec3b color, int idx)
	{
		int firstCamNum = 0;
		for (int i = 0; i < total_num_cameras; i++) {
			if (!CheckOcclusion(i)) {
				firstCamNum = i;
				break;
			}
		}

		uchar v = refV;
		uchar u = refU;
		for (int i = firstCamNum + 1; i < idx; i++) {
			if (!CheckOcclusion(i)) {
				v += (VU[i] >> 4) - 7;
				u += (uchar(VU[i] << 4) >> 4) - 7;
			}
		}

		VU[idx] = uchar((color[2] - v + 7) << 4) + uchar(color[1] - u + 7);

		Y[idx] = color[0];
	}

	void SetColor(uchar v_, uchar u_, uchar y_, int idx)
	{
		int firstCamNum = 0;
		for (int i = 0; i < total_num_cameras; i++) {
			if (!CheckOcclusion(i)) {
				firstCamNum = i;
				break;
			}
		}

		uchar v = refV;
		uchar u = refU;
		for (int i = firstCamNum + 1; i < idx; i++) {
			if (!CheckOcclusion(i)) {
				v += (VU[i] >> 4) - 7;
				u += (uchar(VU[i] << 4) >> 4) - 7;
			}
		}

		VU[idx] = uchar(uchar((v_ - v + 7) << 4) + (u_ - u + 7));

		Y[idx] = y_;
	}
} PPC;

// VUY ������.
typedef struct PPC_S_
{
	ushort geometry[3];
	uchar refV;
	uchar refU;
	vector<uchar> VU;
	vector<uchar> Y;

	PPC_S_()
	{
		// occlusion���� �ʱ�ȭ.
		VU = vector<uchar>(total_num_cameras, uchar(255));
		Y = vector<uchar>(total_num_cameras);
	}

	bool CheckOcclusion(int idx)
	{
		return int(VU[idx]) == 255;
	}

	Vec3b GetColor(int idx)
	{
		Vec3b vuy;
		int firstCamNum = 0;
		for (int i = 0; i < total_num_cameras; i++) {
			if (!CheckOcclusion(i)) {
				firstCamNum = i;
				break;
			}
		}

		uchar v = refV;
		uchar u = refU;
		for (int i = firstCamNum + 1; i <= idx; i++) {
			if (!CheckOcclusion(i)) {
				v += (VU[i] >> 4) - 7;
				u += (uchar(VU[i] << 4) >> 4) - 7;
			}
		}
		vuy[0] = v;
		vuy[1] = u;

		vuy[2] = Y[idx];

		return vuy;
	}

	void SetColor(PPC src)
	{
		refV = src.refV;
		refU = src.refU;

		for (int i = 0; i < total_num_cameras; i++) {
			VU[i] = src.VU[i];
			Y[i] = src.Y[i];
		}
	}

	void SetOcclusion(int idx) {
		VU[idx] = uchar(255);
	}

	// color��  YUV
	void SetRefColor(Vec3b color, int idx)
	{
		//for (int i = 0; i < idx; i++) {
		//	SetOcclusion(i);
		//}

		refV = color[2];
		refU = color[1];
		Y[idx] = color[0];

		VU[idx] = 0;
	}

	// color�� VUY
	void SetRefColor(PointXYZRGB point, int idx)
	{
		//for (int i = 0; i < idx; i++) {
		//	SetOcclusion(i);
		//}

		refV = point.r;
		refU = point.g;
		Y[idx] = point.b;

		VU[idx] = 0;
	}

	// color�� yuv
	void SetColor(Vec3b color, int idx)
	{
		int firstCamNum = 0;
		for (int i = 0; i < total_num_cameras; i++) {
			if (!CheckOcclusion(i)) {
				firstCamNum = i;
				break;
			}
		}

		uchar v = refV;
		uchar u = refU;
		for (int i = firstCamNum + 1; i < idx; i++) {
			if (!CheckOcclusion(i)) {
				v += (VU[i] >> 4) - 7;
				u += (uchar(VU[i] << 4) >> 4) - 7;
			}
		}

		VU[idx] = uchar((color[2] - v + 7) << 4) + uchar(color[1] - u + 7);

		Y[idx] = color[0];
	}

	void SetColor(uchar v_, uchar u_, uchar y_, int idx)
	{
		int firstCamNum = 0;
		for (int i = 0; i < total_num_cameras; i++) {
			if (!CheckOcclusion(i)) {
				firstCamNum = i;
				break;
			}
		}

		uchar v = refV;
		uchar u = refU;
		for (int i = firstCamNum + 1; i < idx; i++) {
			if (!CheckOcclusion(i)) {
				v += (VU[i] >> 4) - 7;
				u += (uchar(VU[i] << 4) >> 4) - 7;
			}
		}

		VU[idx] = uchar(uchar((v_ - v + 7) << 4) + (u_ - u + 7));

		Y[idx] = y_;
	}
} PPC_S;

typedef struct {
	float geometry[3];
	short norm_color[3];
	short res[10][3];//[num_of_cam][color_index]
} PPC_N;
